import { useQuery } from '@tanstack/react-query';
import React, { useState } from 'react';
import useAxiosSecure from '../../../Hooks/useAxiosSecure';
import Container from '../../../Componants/Container/Container';
import TutorCard from './TutorCard';
import Loading from '../../../Componants/Loading/Loading';

const Tutors = () => {

    const axiosSecure = useAxiosSecure();
     const [page, setPage] = useState(1);
      const limit = 12;

    const { data, isLoading } = useQuery({
      queryKey: ["users", page, limit],
      queryFn: async () => {
        const res = await axiosSecure.get("/users/tutor/role", {
          params: { page, limit },
        });
        return res.data;
      },
    });
  
  
  
  const tutors = data?.data || [];
  const totalPages = data?.pages || 1;



  if (isLoading) {
    return <Loading></Loading>
  }
  
    return (
      <div className="pt-17">
        <title>Tutors | eTutionTrack</title>
        <Container>
          <div className="pb-5 pt-10">
            <h1 className="text-2xl font-bold text-center">
              Explore Available Tutors
            </h1>
            <p className="text-sm text-center md:w-3/4 mx-auto text-base-content/60 py-2">
              Browse verified tuition requests from students and find
              opportunities that match your expertise, location, and preferred
              schedule. Start teaching and grow your tutoring career.
            </p>
          </div>
          <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-5">
            {tutors?.map((tutor) => (
              <TutorCard key={tutor?._id} tutor={tutor}></TutorCard>
            ))}
          </div>

          {/* paganation */}
          <div className="flex justify-center pt-5 items-center pb-10">
            <div className="join gap-3">
              {Array.from({ length: totalPages }, (_, i) => {
                const pageNumber = i + 1;

                return (
                  <input
                    key={pageNumber}
                    className="join-item btn btn-square"
                    type="radio"
                    name="options"
                    aria-label={pageNumber}
                    checked={page === pageNumber}
                    onChange={() => setPage(pageNumber)}
                  />
                );
              })}
            </div>
          </div>
        </Container>
      </div>
    );
};

export default Tutors;